﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using SAP.Middleware.Connector;

namespace DLSAPDATA
{
    public class rfc_Connector : IDestinationConfiguration
    {
        public event RfcDestinationManager.ConfigurationChangeHandler ConfigurationChanged;

        public bool ChangeEventsSupported()
        {
            return false;
        }

        public RfcConfigParameters GetParameters(string destinationName)
        {
            if ("SE37".Equals(destinationName))
            {
                RfcConfigParameters param = new RfcConfigParameters();
                param.Add(RfcConfigParameters.AppServerHost, ""); //Server IP
                param.Add(RfcConfigParameters.SystemNumber, ""); //System Number
                param.Add(RfcConfigParameters.SystemID, "");
                param.Add(RfcConfigParameters.User, ""); //SAP User Logon
                param.Add(RfcConfigParameters.Password, ""); //SAP User Passwrod
                param.Add(RfcConfigParameters.SAPRouter, "");
                param.Add(RfcConfigParameters.Client, ""); //Client
                param.Add(RfcConfigParameters.Language, "EN"); 
                param.Add(RfcConfigParameters.Name, "SE37");
                param.Add(RfcConfigParameters.ConnectionIdleTimeout, "600");
                param.Add(RfcConfigParameters.PeakConnectionsLimit, "10");
                param.Add(RfcConfigParameters.PoolSize, "10");

                return param;
            }
            else
            {
                return null;
            }
        }
    }
}