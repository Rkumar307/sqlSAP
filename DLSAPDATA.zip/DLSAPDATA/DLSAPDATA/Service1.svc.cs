﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using SAP.Middleware.Connector;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.Script.Serialization;

namespace DLSAPDATA
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class Service1 : IService1
    {
        string message;
        
        public string Download_KNA1(string kunnr)
        {
            try
            {
                IRfcFunction getDataSAP = GlobalData.rfcRepository.CreateFunction("ZFDLKNA1");
                getDataSAP.SetValue("P_KUNNR", kunnr);

                try
                {
                    getDataSAP.Invoke(GlobalData.rfcDestination);
                }
                catch (Exception ex)
                {
                    message = "SAP ZFDLKNA1 ";
                    message += ex.Message;
                    return message;
                }

                IRfcTable IT_KNA1 = getDataSAP.GetTable("IT_KNA1");
                DataSet1 dsUniversal = new DataSet1();

                DataTable dtKNA1 = dsUniversal.Tables["ZKNA1"];

                dtKNA1 = CreateDataTable(dtKNA1, IT_KNA1);


                SqlConnection con = GetSQLConn();
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlTransaction transaction = con.BeginTransaction();

                SqlCommand command = new SqlCommand("sp_DLKNA1", con);
                command.Transaction = transaction;
                command.Parameters.Add(new SqlParameter("@dtKNA1", SqlDbType.Structured));
                command.Parameters["@dtKNA1"].Value = dtKNA1;
                command.Parameters["@dtKNA1"].TypeName = "zkna1Type";

                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.CommandTimeout = 600000;
                int result = command.ExecuteNonQuery();

                transaction.Commit();
                transaction.Dispose();
                IT_KNA1.Clear();
                message = "Download data completed. ";
                message += "Total Data :" + dtKNA1.Rows.Count + " rows. ";

                return message;
            }
            catch (Exception ex)
            {
                return ex.Message.ToString();
            }
        }


        public string GetAppSetting(string key)
        {
            try
            {
                return ConfigurationManager.AppSettings[key];
            }
            catch (Exception)
            {
                return "";
            }
        }

        public SqlConnection GetSQLConn()
        {
            string ConnString = GetAppSetting("ConnString");
            SqlConnection koneksi = new SqlConnection(ConnString);
            return koneksi;
        }


        public static DataTable CreateDataTable(DataTable dt, IRfcTable rfcTable)
        {
            foreach (IRfcStructure row in rfcTable)
            {
                DataRow newRow = dt.NewRow();
                for (int element = 0; element < rfcTable.ElementCount; element++)
                {
                    RfcElementMetadata metadata = rfcTable.GetElementMetadata(element);
                    var nrow = newRow[element];
                    var rrow = row.GetString(metadata.Name);
                    newRow[element] = row.GetString(metadata.Name);

                }
                dt.Rows.Add(newRow);
            }

            return dt;

        }



        public string GetData(int value)
        {
            return string.Format("You entered: {0}", value);
        }

        public CompositeType GetDataUsingDataContract(CompositeType composite)
        {
            if (composite == null)
            {
                throw new ArgumentNullException("composite");
            }
            if (composite.BoolValue)
            {
                composite.StringValue += "Suffix";
            }
            return composite;
        }
    }
}
