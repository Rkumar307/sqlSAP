﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using SAP.Middleware.Connector;

namespace DLSAPDATA
{
    public class GlobalData
    {
        public static RfcRepository rfcRepository;
        public static RfcDestination rfcDestination;
    }
}